package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DAOServiceImpl implements DAOService {
		private Connection con;
		private Statement stmnt;
	@Override
	public void connectDB() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/signup_LoginUp", "root", "test");
			stmnt=con.createStatement();
		} catch (Exception e) {
		e.printStackTrace();
		}
	}

	@Override
	public void saveSignUp(String name, String mobile, String email, String password) {
			try {
				stmnt.executeUpdate("insert into signUp values('"+name+"', '"+mobile+"', '"+email+"', '"+password+"')");
				
			} catch (Exception e) {
					e.printStackTrace();
			}
	}

	@Override
	public boolean login(String email, String password) {
		try {
			ResultSet result = stmnt.executeQuery("select * from signUp where email='"+email+"' and password='"+password+"'");
		return	result.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
		
	}

	@Override
	public void profile(String name, String email, String mobile, String address, String city, String state,
			String pincode, String country, String company_name, String occupation, String year_of_experience) {
		try {
			stmnt.executeUpdate("insert into profile values('"+name+"',  '"+email+"','"+mobile+"', '"+address+"','"+city+"','"+state+"','"+pincode+"','"+country+"','"+company_name+"','"+occupation+"','"+year_of_experience+"')");
			
		} catch (Exception e) {
				e.printStackTrace();
		}
	}

}
