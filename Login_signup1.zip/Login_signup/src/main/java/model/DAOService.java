package model;

public interface DAOService {
		public void connectDB();
		public void saveSignUp(String name,String mobile,String email, String password);
		public boolean login(String email, String password);
		public void profile(String name,String email,String mobile, String address,String city,String state,String pincode,String country,String company_name,String occupation,String year_of_experience);
}
