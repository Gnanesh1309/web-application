package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DAOService;
import model.DAOServiceImpl;

@WebServlet("/profile")
public class ProfileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ProfileController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String mobile = request.getParameter("mobile");
			String address = request.getParameter("address");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String pincode = request.getParameter("pincode");
			String country = request.getParameter("country");
			String company_name = request.getParameter("company_name");
			String occupation = request.getParameter("occupation");
			String year_of_experience = request.getParameter("year_of_experience");
			

				DAOService service = new DAOServiceImpl();
				service.connectDB();
				service.profile(name, email, mobile, address, city, state, pincode, country, company_name, occupation, year_of_experience);
				request.setAttribute("gud", "Profile Saved");
				RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/views/profile.jsp");
				rd.forward(request, response);
			
	
	
	}

}
